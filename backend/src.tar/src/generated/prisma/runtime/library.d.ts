declare module '@prisma/client/runtime/library' {
  export const PrismaClientKnownRequestError: any
  export const PrismaClientUnknownRequestError: any
  export const PrismaClientRustPanicError: any
  export const PrismaClientInitializationError: any
  export const PrismaClientValidationError: any
  export const Decimal: any
}
